	import java.io.File;
	import java.io.IOException;
	import java.io.PrintWriter;
	import java.util.Scanner;

	public class ReverseFile
	{
	    public static void main(String[] args) throws IOException
	       {
	          try{
	         String source = args[0];
	          String target = args[1];

	          File file=new File(source);

	          Scanner sc=new Scanner(file);
	          PrintWriter pwriter =new PrintWriter(source);

	          while(sc.hasNextLine())
	          {
	             String s=sc.nextLine();
	             StringBuffer buffer = new StringBuffer(s);
	             buffer=buffer.reverse();
	             String bs=buffer.toString();
	             pwriter.println(bs);
	          }
	          sc.close();    
	          pwriter.close();
	          System.out.println("File is copied successful!");
	          }

	          catch(Exception e){
	              System.out.println("Something went wrong");
	          }
	       }
	}
