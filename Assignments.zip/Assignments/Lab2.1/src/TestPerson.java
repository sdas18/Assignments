
public class TestPerson 
{

	public static void main(String[] args)
	{
		Person person1 = new Person();
		person1.getDetails("Abhinav", "Warney", 'M', 21, 78);
		person1.dispDetails();
	}

}
