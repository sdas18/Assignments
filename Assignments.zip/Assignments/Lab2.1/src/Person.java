public class Person 
{
	String firstName;
	String lastName;
	char gender;
	int age;
	float weight;

	public void getDetails(String fName,String lName,char sex, int age1,float wght)
	{
		firstName = fName;
		lastName = lName;
		gender = sex;
		age = age1;
		weight = wght;
	}
	public void dispDetails()
	{
		System.out.println("First Name:" + firstName);
		System.out.println("Last Name:" + lastName);
		System.out.println("Gender:" + gender);
		System.out.println("Age:" + age);
		System.out.println("Weight:" + weight);
		System.out.println();
	}

}
