import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.io.Reader;
public class Lab9_1 {	
	public static void main(String[] args) {
		FileInputStream fis = null;
		RandomAccessFile raf = null;

		String characterEncoding = "utf-8";

		if(args.length==3) {
			characterEncoding = args[2];
		}

		try{    
			File in = new File(args[0]);
			fis = new FileInputStream(in);  
			Reader r = new InputStreamReader(fis,characterEncoding); 
			File out = new File(args[1]);
			raf = new RandomAccessFile(out, "rw");
			raf.setLength(in.length());
			char[] buff = new char[1];
			long position = in.length(); 
			while((r.read(buff))>-1) {
				Character c = buff[0];
				String s = c+"";
				byte[] bBuff = s.getBytes(characterEncoding);
				position = position-bBuff.length;
				raf.seek(position);
				raf.write(bBuff);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				fis.close();
			} catch (Exception e2) {
			}
			try {
				raf.close();
			} catch (Exception e2) {
			}
		}

	}

}



