import java.util.ArrayList;
import java.util.List;


public class RemoveList {

	public static void main(String[] args) {
		List<String>List1 = new ArrayList<>();
		List<String>List2 = new ArrayList<>();
		List1.add("Abhinav");
		List1.add("Abhijeet");
		List1.add("Abhishek");
		List2.add("Abhinav");
		List2.add("Muskaan");
		List2.add("Abhijeet");
		List2.add("Abhishek");
		List2.add("akriti");
		System.out.println(removeElements(List1, List2));
	}
	public static List<String> removeElements(List<String>List1,List<String>List2){
		List2.removeAll(List1);
		return List2;
	}
}
