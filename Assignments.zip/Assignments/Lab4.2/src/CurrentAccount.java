public class CurrentAccount extends Account
{
	public double overDraftLimit = 10000;
	@Override
	public void withdraw(double withdrawAmount)
	{
		
		if(withdrawAmount>=getBalance())
		{
			if(withdrawAmount>getBalance() + overDraftLimit)
				{
				System.out.println("Sorry OverDraft Limit Exceeded!!");
				}
			else
				{
				System.out.println("withdraw completed!!");
				super.withdraw(withdrawAmount);
				}
		
		}
	}
}

	

