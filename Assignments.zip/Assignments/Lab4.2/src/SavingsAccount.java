
public class SavingsAccount extends Account
{
	public final double minBalance = 500.0;
	@Override
	public void withdraw(double withdrawAmount)
	{
		if(super.getBalance()>=minBalance)
		{
		super.withdraw(withdrawAmount);
		}
		else 
			System.out.println("Balance Less Than 500.");
	}
}
