import java.util.Random;


public class Account
{

	private long accNum;
	private double balance;
	private Person accHolder;
	
	
	public long getAccNum() 
	{
		return accNum;
	}

	public void setAccNum() 
	{
		this.accNum = (long) Math.pow(10, 10 - 1) + new Random().nextInt(9000);
	}

	public Person getAccHolder() {
		return accHolder;
	}

	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	public void setIntBalance(double balance) {
		this.balance = balance;
		if(balance<500.0)
		{
			System.out.println("Please ensure Minimum Balance of 500!");
		}
	}

	
	public void setBalance(double balance) {
		this.balance = balance;
		
	}
	
	public void deposit(double depAmount)
	{
		balance = balance + depAmount;
	}
	public void withdraw(double withdrawAmount)
	{
		balance = balance - withdrawAmount;
	}
	public double getBalance()
	{
		return balance;
	}
	public String toString()
	{
		return "\nName : " + accHolder.getName() + "\nAge : " + accHolder.getAge() + "\nAccount Number : " + accNum + "\nBalance : " + balance; 
	}
}
