import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;


public class DurationDays
{

	public static void main(String[] args) 
	{
		LocalDate now = LocalDate.now();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Year :");
		int year = sc.nextInt();
		System.out.println("\nEnter Month :");
		int month = sc.nextInt();
		System.out.println("\nEnter Day :");
		int day = sc.nextInt();
		LocalDate userDate = LocalDate.of(year, month, day);
		Period diff = Period.between(userDate, now);
		System.out.printf("Difference is %d years, %d months and %d days old",
                diff.getYears(), diff.getMonths(), diff.getDays());
	}

}
