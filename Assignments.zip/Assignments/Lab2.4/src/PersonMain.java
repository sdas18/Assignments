import java.util.Scanner;


public class PersonMain 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Using Constructor.");
		Person abhinav = new Person("Abhinav","Warney",'M');
		abhinav.dispDetails();

		System.out.println("Enter your Phone No: "+ abhinav.firstName);
		String abhinavPhone = sc.next();
		abhinav.setPhone(abhinavPhone);
		abhinav.dispPhone();
		
		System.out.println("-------------------------------------");
		
		Person abhijeet = new Person(); //---using getter and setter----------//
		abhijeet.setFirstName("Abhijeet");
		abhijeet.setLastName("Kumar");
		abhijeet.setGender('M');
		abhijeet.dispDetails();
		System.out.println("Enter your Phone No: "+ abhijeet.firstName);
		String abhijeetPhone = sc.next();
		abhijeet.setPhone(abhijeetPhone);
		abhijeet.dispPhone();

	}

}
