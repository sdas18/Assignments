import java.util.Scanner;
public class PersonMain 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		Gender currentGender = Gender.M;
		System.out.println("Enter 1: Male(M) 2: Female(F)");
		int index = sc.nextInt();
		switch(index)
		{
		case 1: currentGender = Gender.M;break;
		default : currentGender = Gender.F;
		}
		
		Person abhinav = new Person("Abhinav","Warney",currentGender);
		abhinav.dispDetails();
	}

}
