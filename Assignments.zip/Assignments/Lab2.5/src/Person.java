
public class Person
{
	private String firstName;
	private String lastName;
	private Gender gender;
	
	
	
	public Person()
	{
		firstName = null;
		lastName = null;
		gender = Gender.M;
	}
	
	public Person(String firstName,String lastName,Gender gender)
	{
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
	}
	 public void dispDetails()
	 {
		System.out.println("First Name:" + firstName);
		System.out.println("Last Name:" + lastName);
		System.out.println("Gender:" + gender);
	 }
}
