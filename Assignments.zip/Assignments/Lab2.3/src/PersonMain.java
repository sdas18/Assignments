
public class PersonMain 
{
	public static void main(String[] args) 
	{
		Person abhinav = new Person("Abhinav","Warney",'M'); //------------using constructor--
		abhinav.dispDetails();
		System.out.println("----------------------------"); 
		Person abhijeet = new Person();       //-------------Using Getter and Setter-------
		abhijeet.setFirstName("Abhijeet");
		abhijeet.setLastName("Kumar");
		abhijeet.setGender('M');
		System.out.println("FirstName :"+ abhijeet.getFirstName());
		System.out.println("LastName :"+ abhijeet.getLastName());
		System.out.println("Gender :"+ abhijeet.getGender());
	}

}
