import java.time.LocalDate;
import java.util.Scanner;


public class TestWarrantyPeriod 
{

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Purchase Dtae in Format yyyy-mm-dd :");
		String inputDate = sc.next();
		int year1 = Integer.parseInt(inputDate.substring(0,4));
		int month1 = Integer.parseInt(inputDate.substring(5,7));
		int day1 = Integer.parseInt(inputDate.substring(8,10));
		LocalDate purchaseDate = LocalDate.of(year1,month1,day1);
		System.out.println("Enter Warranty Period: " + "\nNo of Years: ");
		int noOfYears = sc.nextInt();
		System.out.println("\nNo of Months: ");
		int noOfMonths = sc.nextInt();
		System.out.println("Expire Date :" + purchaseDate.plusYears(noOfYears).plusMonths(noOfMonths));

	}

}
