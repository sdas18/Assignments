
public class Lab7_2 {

}
