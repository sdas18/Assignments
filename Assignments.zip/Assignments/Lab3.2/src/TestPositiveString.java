import java.util.Scanner;
public class TestPositiveString 
{

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter string to Test:");
		String testString = sc.next();
		boolean result = checkString(testString);
		if(result == true)
			System.out.println("String is Positive!!");
		else
			System.out.println("String is Negative!!");		
	}
	
	public static boolean checkString(String testString)
	{
		String str = testString;
		int count = 0;
		for (int i = 0; i < (str.length() - 1); i++) 
		{
			if(str.charAt(i)<str.charAt(i+1))
				count++;
		}	
		if(count == str.length() - 1)
			return true;
		else
			return false;
		}

}
