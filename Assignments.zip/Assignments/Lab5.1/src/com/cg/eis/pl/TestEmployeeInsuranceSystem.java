package com.cg.eis.pl;
import java.util.Scanner;

import com.cg.eis.bean.*;
import com.cg.eis.service.*;


public class TestEmployeeInsuranceSystem 
{

	public static void main(String[] args) 
	{
		Scanner scan = new Scanner(System.in);
		Employee emp = new Employee();
		
		System.out.println("Enter Emp Id :");
		int id = scan.nextInt();
		System.out.println("Enter Emp Name :");
		String name = scan.next();
		System.out.println("Enter Emp Salary :");
		float sal = scan.nextInt();
		System.out.println("Choose Emp Designation :");
		String designation = scan.next();
		emp.setEmpId(id);
		emp.setEmpName(name);
		emp.setEmpSal(sal);
		emp.setDesignation(designation);
		Service ser = new Service();
		
		System.out.println(ser.dispEmp(emp));
		System.out.println("Scheme for Employees = " + ser.employeeInsuranceScheme(emp));
	}

}
