package com.cg.eis.bean;

public class Employee 
{
	private int empId;
	private String empName;
	private double empSal;
	private String designation;
	


	public int getEmpId() {
		return empId;
	}

	public String getEmpName() {
		return empName;
	}

	public double getEmpSal() {
		return empSal;
	}

	public String getDesignation() {
		return designation;
	}

	
	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public void setEmpSal(double empSal) {
		this.empSal = empSal;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}
	
}
