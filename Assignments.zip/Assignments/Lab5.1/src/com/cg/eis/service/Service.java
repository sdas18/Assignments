package com.cg.eis.service;

import com.cg.eis.bean.Employee;

public class Service implements EmployeeService
{
	public Service(){};
	@Override
	public String employeeInsuranceScheme(Employee emp)
	{
		if(emp.getDesignation().equals("System_Associate") && emp.getEmpSal()>=5000 && emp.getEmpSal()<20000)
		{
			return "Scheme C";
		}
		else if(emp.getDesignation().equals("Programmer") && emp.getEmpSal()>=20000 && emp.getEmpSal()<40000)
		{
			return "Scheme B";
		}
		else if(emp.getDesignation().equals("Manager") && emp.getEmpSal()>=40000)
		{
			return "Scheme A";
		}
		else if(emp.getDesignation().equals("Clerk") && emp.getEmpSal()<5000)
		{
			return "No Scheme";
		}
		else
		{
			return "No_Scheme";
		}
	}
	public String dispEmp(Employee emp)
	{
		return "Emp name =" + emp.getEmpName() + "\nEmp Id = "+emp.getEmpId() + "\nEmp Salary" + emp.getEmpSal() + "\nEmp Designation = " + emp.getDesignation();
	}
	
	
}
