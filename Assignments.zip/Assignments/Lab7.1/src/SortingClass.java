import java.util.ArrayList;
import java.util.Collections;
public class SortingClass {

	public static void main(String[] args) {
		int array[] = {12,23,96,45};
		int[] finalResult = arraySort(array);
		for (int i = 0; i < array.length; i++) {
			System.out.print(finalResult[i]+" ");
		}
	}
	public static int[] arraySort(int[] array){
		ArrayList<String>arrayList = new ArrayList<>();
		String[] array2 = new String[array.length];
		for (int i = 0; i < array.length; i++) {
			StringBuilder input1 = new StringBuilder(); 
			input1.append(array[i]); // append a string into StringBuilder input1 
			input1 = input1.reverse(); // reverse StringBuilder input1 
			array2[i] = ""+input1;
			arrayList.add(array2[i]);
			Collections.sort(arrayList);
		} 
		int result[] = new int[arrayList.size()];
		for (int i = 0; i < result.length; i++) {
			result[i] = Integer.parseInt(arrayList.get(i));
		}
		return result;
	}
}