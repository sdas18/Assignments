import java.util.Random;


public class TestClientAcount 
{

	public static void main(String[] args)
	{
		Person person1 = new Person();
		Person person2 = new Person();
		
		person1.setName("Smith");
		person1.setAge(20);
		person2.setName("Kathy");
		person2.setAge(23);
		
		Account smith = new Account();
		Account kathy = new Account();
		
		smith.setAccNum((long) Math.pow(10, 10 - 1) + new Random().nextInt(9000));
		kathy.setAccNum((long) Math.pow(10, 10 - 1) + new Random().nextInt(9000));
		
		smith.setIntBalance(2000.0F);
		kathy.setIntBalance(4000.0F);
		
		smith.deposit(2000.0F);
		kathy.withdraw(3000.0F);
		
		smith.setAccHolder(person1);
		kathy.setAccHolder(person2);
		
		System.out.println("Smith Balance : "+ smith.getBalance());
		System.out.println("Kathy Balance : "+ kathy.getBalance());
		
		System.out.println("------------------------------------\nAccount Holder Details :\n-------------------------------------" 
		+ smith.toString() + "\n" +"------------------------------------\n"+ kathy.toString());
		
	}

}
