
public class SortStringAlphabetical 
{

	public static void main(String[] args) 
	{

		String[] testStr= {"Muskaan","Shivam","Abhijeet","Aman","Simran"};
		String[] result = sortAlphabetical(testStr);
		for (int i = 0; i < result.length; i++)
		{
			System.out.println(result[i]);
		}
	}

	public static String[] sortAlphabetical(String[] testStr)	
	{
		for (int i = 0; i < testStr.length-1; i++)
		{
			for (int j = i+1; j < testStr.length; j++) 
			{
				if(testStr[i].compareTo(testStr[j])>0)
				{
					String temp = testStr[i];
					testStr[i] = testStr[j];
					testStr[j] = temp;
				}

			}
		}
		return testStr;
	}
}
