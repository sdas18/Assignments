import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
public class GetSquare {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer>arrayList=new ArrayList<>();
		arrayList.add(2);
		arrayList.add(3);
		arrayList.add(4);
		arrayList.add(5);
		System.out.println(getSquare(arrayList));
	}

	private static Map<Integer,Integer> getSquare(ArrayList<Integer> arrayList) {
		int sq,squ;
		HashMap<Integer,Integer> square=new HashMap<>();
		for(int i=0;i<arrayList.size();i++)
		{
		    sq=arrayList.get(i);
			 squ=sq*sq;
			square.put(sq, squ);
		}
		
		
		return square;
	}

}