import java.util.Scanner;
import java.util.*;

public class StringOperation 
{

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter String Here: ");
		String testString = sc.next();
		System.out.println("Choose the operations to Perform on String :");
		System.out.println("1) To Add String. \n2) To Replace Odd Position of String With '#'. \n3) To Remove Duplicate Characters from String. \n4) To change Character at Odd positon to UpperCase.");
		int index = sc.nextInt();
		switch(index)
		{
		case 1:System.out.println("result :" + addString(testString));break;
		case 2:System.out.println("result :" + replaceOddPosition(testString));break;
		case 3:System.out.println("result :" + removeDuplicateChar(testString));break;
		case 4:System.out.println("result :" + changeOddtoUpper(testString));break;
		default: System.out.println("You Entered wrong Choice");
		}
	}

	public static String addString(String testStr) //-----method to add String.
	{
		String newStr = testStr.concat(testStr);
		return newStr;
	}

	public static String replaceOddPosition(String testStr) //-------------method to replace character at odd position with '#'.
	{
		String newStr = "";
		for (int i = 0; i < testStr.length(); i++) 
		{
			if(((i+1)%2) != 0)
			{
				newStr = newStr +"#";
			}
			else
			{
				newStr += testStr.charAt(i);
			}
		}
		return newStr;
	}

	public static String removeDuplicateChar(String testStr) //------to remove duplicate characters
	{
		String newStr = "";
		for (int i = 0; i < testStr.length(); i++)
		{
			if(!newStr.contains(""+testStr.charAt(i)))
			{
				newStr +=""+testStr.charAt(i);
			}
		}
		return newStr;
	}
	/*{
		String newStr = "";
		int count = 0;
		for (int i = 0; i < (testStr.length()-1); i++) 
		{    
			int j=0;
			for( j = 0; j<i;j++)
			{
				if(testStr.charAt(i)==testStr.charAt(j))
					break;
			}
			if(j==i)
				{
				newStr += (""+testStr.charAt(i));
				}
		}
		return newStr;
	}
	 */

	public static String changeOddtoUpper(String testStr) //-----to change characters at odd positions to UPPERCASE
	{
		String newStr = "";
		for (int i = 0; i < testStr.length(); i++) 
		{
			if(((i+1)%2) != 0)
			{
				newStr += (""+testStr.charAt(i)).toUpperCase();
			}
			else
			{
				newStr += testStr.charAt(i);
			}
		}
		return newStr;
	}


}
