import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;


public class testZoneDate
{

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter ZoneID:");
		System.out.println("1.America/New_York" + "\n2.Europe/London" + "\n3.Asia/Tokyo" +
		"\n4.US/Pacific"+ "\n5.Africa/Cairo" + "\n6.Australia/Sydney");
		int choice = sc.nextInt();
		switch(choice)
		{
		case 1:System.out.println(zoneDate("America/New_York"));
				break;
		case 2:System.out.println(zoneDate("Europe/London"));
				break;
		case 3:	System.out.println(zoneDate("Asia/Tokyo"));
				break;
		case 4:System.out.println(zoneDate("US/Pacific"));
				break;
		case 5:System.out.println(zoneDate("Africa/Cairo"));
				break;
		default:System.out.println(zoneDate("Australia/Sydney"));
		}
	}
	
	public static ZonedDateTime  zoneDate(String id)
	{
		ZoneId zoneid = ZoneId.of(id);
		ZonedDateTime zoned = ZonedDateTime.now(zoneid);
		return zoned;
	}

}
