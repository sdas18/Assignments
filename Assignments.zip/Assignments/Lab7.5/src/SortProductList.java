import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class SortProductList {

	public static void main(String[] args) {
		List<String>productList = new ArrayList<String>();
		productList.add("Xiomi");
		productList.add("Samsung");
		productList.add("LG");
		productList.add("Apple");
		productList.add("Panasonic");
		Collections.sort(productList);
		for (int i = 0; i < productList.size(); i++) {
			System.out.println(productList.get(i));
		}
	}
}
