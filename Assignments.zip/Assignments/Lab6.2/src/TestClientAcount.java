import java.util.Scanner;




public class TestClientAcount 
{

	public static void main(String[] args)throws NotValidAgeExcpetion
	{
		Scanner sc = new Scanner(System.in);
		Person[] person = new Person[2];
		Account[] accHolder = new Account[2];
		for (int i = 0; i < person.length; i++) 
		{
			person[i] = new Person();
			System.out.println("Enter Account Holder Details: \nEnter Name :");
			String accHoldrName = sc.next();
			person[i].setName(accHoldrName);
			System.out.println("Enter Age:");
			int accHoldrAge = sc.nextInt();
			try{
				person[i].checkAge(accHoldrAge);	
			}
			catch(NotValidAgeExcpetion e){
					System.out.println(e.getMessage() + "\nTerminating Application!");
					System.exit(0);
			}
			person[i].setAge(accHoldrAge);
			System.out.println("Choose Account Type : \n1.SavingsAccount \t 2.Current Account");
			int choice = sc.nextInt();
			switch(choice)
			{
			case 1 :accHolder[i] = new SavingsAccount();
			accHolder[i].setAccNum();
			accHolder[i].setAccHolder(person[i]);
			break;
			case 2 : accHolder[i] = new CurrentAccount();
			accHolder[i].setAccNum();
			accHolder[i].setAccHolder(person[i]);
			break;
			default : System.out.println("Entered wrong option!!");	
					System.exit(0);			
			}	
			System.out.println("Set Initial Balance :");
			double intBalance = sc.nextDouble();
			accHolder[i].setIntBalance(intBalance);
			System.out.println("Choose Operatins: \n1.Deposit \t 2.Withdraw \t 3.Display Balance \t 4.Account Details");
			int index = sc.nextInt();
			switch(index)
			{			
			case 1 :System.out.println("-------------------------");
					System.out.println("Enter amount to Deposit:");
					double depAmount = sc.nextDouble();
					accHolder[i].deposit(depAmount);
					System.out.println("-------------------------");
					System.out.println("Current Balance : " + accHolder[i].getBalance());
					System.out.println("-------------------------");
					break;
			case 2 :System.out.println("-------------------------");
					System.out.println("Enter amount to withdraw:");
					double wdrawAmount = sc.nextDouble(); 
					accHolder[i].withdraw(wdrawAmount);
					System.out.println("-------------------------");
					System.out.println("Current Balance : " + accHolder[i].getBalance());
					System.out.println("-------------------------");
					break;
			case 3: System.out.println("-------------------------");
					System.out.println(person[i].getName() + " Balance : "+ accHolder[i].getBalance());
					System.out.println("-------------------------");
					break;
			case 4: System.out.println("-------------------------");
					System.out.println(accHolder[i].toString());
					System.out.println("-------------------------");
					break;
			default:System.out.println("-------------------------");
					System.out.println("Wrong Input!!");
					System.exit(0);
			}
		}
	}
}
