
public class NotValidAgeExcpetion extends Exception{
	public NotValidAgeExcpetion(String s){
	super(s);
	}
}
