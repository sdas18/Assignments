import java.util.Scanner;


public class PersonMain 
{
	public static void main(String[] args) throws NameNotPresent 
	{
		Scanner sc = new Scanner(System.in);
		String fName="",lName="";
		System.out.println("Enter First Name:");
		fName = sc.nextLine();
		if(fName.isEmpty())
		{
			try
			{
				throw new NameNotPresent("Name Invalid");
			}
			catch(NameNotPresent ex)
			{
				System.out.println("Please Enter First Name!");
				System.out.println(ex.getMessage());
			}
		}
		else
		{
			System.out.println("Enter Last Name");
			lName = sc.nextLine(); 
			if(lName.isEmpty())
			{
				try
				{
					throw new NameNotPresent("Please Enter Last Name!");
				}
				catch(NameNotPresent ex)
				{
					System.out.println("Caught");
					System.out.println(ex.getMessage());
				}
			}
		}

		char gen = sc.next().charAt(0);
		Person pm1 = new Person(fName,lName,gen);
		pm1.dispDetails();
		pm1.personPhoneNumber(896898183);
	}

}
