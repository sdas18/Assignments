public class Person
{
	private String firstName;
	private String lastName;
	private char gender;
	
		
	public Person()
	{
		firstName = null;
		lastName = null;
		gender = '\u0000';
	}
	
	public Person(String firstName,String lastName,char gender)
	{
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
	}
	 public void dispDetails()
	 {
		System.out.println("First Name:" + firstName);
		System.out.println("Last Name:" + lastName);
		System.out.println("Gender:" + gender);
	 }
	 public void personPhoneNumber(long number)
	 {
		 System.out.println("Phone Number : " + number);
	 }
}
