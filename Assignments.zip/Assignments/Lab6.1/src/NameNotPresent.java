
public class NameNotPresent extends Exception {
	public NameNotPresent(String s)
	{
		super(s);
	}
}
