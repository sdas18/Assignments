import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;


public class DurationDays
{

	public static void main(String[] args) 
	{
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter 1st Date");
		String date1 = sc.next();		
		int year1 = Integer.parseInt(date1.substring(0,4));
		int month1 = Integer.parseInt(date1.substring(5,7));
		int day1 = Integer.parseInt(date1.substring(8,10));
		LocalDate firstDate = LocalDate.of(year1,month1,day1);
		System.out.println("Enter 2st Date");
		String date2 = sc.next();
		int year2 = Integer.parseInt(date2.substring(0,4));
		int month2 = Integer.parseInt(date2.substring(5,7));
		int day2 = Integer.parseInt(date2.substring(8,10));
		
		LocalDate secondDate = LocalDate.of(year2,month2,day2);
		Period diff = Period.between(firstDate, secondDate);
		System.out.printf("Difference is %d years, %d months and %d days old",
                Math.abs(diff.getYears()), Math.abs(diff.getMonths()), Math.abs(diff.getDays()));
	}

}
