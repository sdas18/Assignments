public class CurrentAccount extends Account
{
	public double overDraftLimit = 10000;
	@Override
	public void withdraw(double withdrawAmount)
	{
		double newBalance = super.getBalance();
		if(withdrawAmount>=getBalance())
		{
			if(withdrawAmount>getBalance() + overDraftLimit)
				{
				System.out.println("Sorry OverDraft Limit Exceeded!!");
				}
			else
				{
				System.out.println("withdraw completed!!");
				newBalance = newBalance - withdrawAmount;
				super.setBalance(newBalance);
				super.getBalance();
				}
		
		}
	}
}

	

