
public class SavingsAccount extends Account
{
	public final double minBalance = 500.0;
	@Override
	public void withdraw(double withdrawAmount)
	{
		double newBalance = super.getBalance();
		if(super.getBalance()>=minBalance)
		{
		newBalance = newBalance - withdrawAmount;
		super.setBalance(newBalance);
		super.getBalance();
		}
		else 
			System.out.println("Balance Less Than 500.");
	}
}
