import java.util.Scanner;


public class TestJobSeeker
{

	public static void main(String[] args) 
	{
		Scanner scan = new Scanner(System.in);
		StringBuilder userName = new StringBuilder();
		System.out.println("Create Your Username with _job at End : ");
		String userName1 = scan.next();
		userName.append(userName1);
		
		System.out.println(validUserName(userName));
	}
	
	public static boolean validUserName(StringBuilder userName)
	{
		
		
		if(userName.length()>7 && userName.toString().contains("_job")) 
			return true;
		else 
			return false;
		
		
	}

}
